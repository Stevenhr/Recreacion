@extends('master')                              

@section('content') 
        
              
            <div class="content">
                <div class="title">IDRD</div>
		<div class="title">Laravel 5</div>
            </div>
       
            
       
@stop
