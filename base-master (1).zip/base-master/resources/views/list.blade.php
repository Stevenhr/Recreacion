@extends('master')                              

@section('content') 
	{!! $lista !!}
@stop
