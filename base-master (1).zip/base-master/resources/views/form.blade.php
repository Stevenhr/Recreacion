@extends('master')                              

@section('content') 
	{!! $formulario !!}
@stop
