<?php

namespace App;

use Idrd\Usuarios\Repo\Documento as MDocumento;

class Documento extends MDocumento
{
    //
}
