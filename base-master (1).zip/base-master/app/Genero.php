<?php

namespace App;

use Idrd\Usuarios\Repo\Genero as MGenero;

class Genero extends MGenero
{
    //
}
