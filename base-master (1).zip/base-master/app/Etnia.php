<?php

namespace App;

use Idrd\Usuarios\Repo\Etnia as MEtnia;

class Etnia extends MEtnia
{
    
}
