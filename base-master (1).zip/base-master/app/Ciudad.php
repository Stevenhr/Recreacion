<?php

namespace App;

use Idrd\Usuarios\Repo\Ciudad as MCiudad;

class Ciudad extends MCiudad
{
    //
}
