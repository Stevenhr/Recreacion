<?php

namespace App;

use Idrd\Usuarios\Repo\Pais as MPais;

class Pais extends MPais
{
    //
}
